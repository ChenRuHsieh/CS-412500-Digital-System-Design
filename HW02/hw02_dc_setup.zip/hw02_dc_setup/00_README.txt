1. Virtual Library Setup for NTHU VLSI/CAD Lab
2. Rename the file "synopsys_dc.setup" to .synopsys_dc.setup
   and put it in your working directory.
